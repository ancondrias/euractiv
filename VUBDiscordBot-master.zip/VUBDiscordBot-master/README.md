# VUBDiscordBot
This is the open-source code of the VUB Discord Bot (also nicknamed 'Foxxy').
Get in touch with Carlo Giudice on Discord (Høpe#1030) or through social media.