// Importing module
module.exports = {

  name: 'twitch',
  description: "links the BSG gtgv twich channel!",
  execute(message){

    // Functions
    message.channel.send("https://www.twitch.tv/stvebsg")

  }
}
